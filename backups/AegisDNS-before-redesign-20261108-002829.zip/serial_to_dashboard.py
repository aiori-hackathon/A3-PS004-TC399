﻿"""Forward ESP32 DNSSEC telemetry to the local AegisDNS dashboard."""

import argparse
import importlib
import json
import logging
import re
import sys
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from urllib.error import URLError

LOG = logging.getLogger("esp32-dashboard-bridge")

HANDSHAKE_RE = re.compile(
    r"^TLS_HANDSHAKE_OK,handshake_ms=(\d+),free_heap=(\d+)$"
)

TLS_FAILURE_RE = re.compile(
    r"^TLS_CONNECT_FAILED,code=(-?\d+),(.*)$"
)

RESULT_RE = re.compile(
    r"^RESULT,([^,]+),([^,]+),rcode=(\d+),AD=([01]),"
    r"id_match=([01]),latency_ms=(\d+(?:\.\d+)?),free_heap=(\d+)$"
)


def parse_serial_line(line: str) -> dict | None:
    """Convert ESP32 serial records into dashboard-compatible metrics."""

    line = line.strip()

    # Successful TLS handshakes are logged but are not DNSSEC metrics.
    if HANDSHAKE_RE.fullmatch(line):
        return None

    # Report TLS connection failures as ERROR metrics.
    if match := TLS_FAILURE_RE.fullmatch(line):
        return {
            "query": "TLS connection",
            "type": "TLS",
            "status": "ERROR",
            "latency_ms": 0.0,
            "client": "ESP32",
        }

    if match := RESULT_RE.fullmatch(line):
        query = match.group(1)[:253]
        response_text = match.group(2).upper()
        rcode = int(match.group(3))
        ad = match.group(4) == "1"
        latency = float(match.group(6))

        # Interpret the DNS response and DNSSEC AD flag.
        if rcode == 0 and ad:
            status = "SECURE"
        elif rcode == 0 and not ad:
            status = "INSECURE"
        elif rcode == 2 and query.lower() == "bogus.aegis.test":
            # This is the deliberately corrupted DNSSEC test domain.
            status = "BOGUS"
        else:
            status = "ERROR"

        return {
            "query": query,
            "type": "A",
            "status": status,
            "latency_ms": latency,
            "client": "ESP32",
        }

    return None


def post_metric(dashboard_url: str, metric: dict) -> None:
    """Send one metric to the dashboard API."""

    payload = dict(metric)
    payload["timestamp"] = datetime.now(timezone.utc).isoformat()

    request = Request(
        f"{dashboard_url.rstrip('/')}/api/metrics",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    with urlopen(request, timeout=3) as response:
        if response.status != 202:
            raise RuntimeError(
                f"Dashboard returned HTTP {response.status}"
            )


def run(port: str, baud: int, dashboard_url: str) -> None:
    try:
        serial = importlib.import_module("serial")
    except ImportError as exc:
        raise RuntimeError(
            "pyserial is required. Install it with: python -m pip install pyserial"
        ) from exc

    LOG.info("Opening ESP32 on %s at %d baud", port, baud)
    LOG.info("Dashboard endpoint: %s/api/metrics", dashboard_url)

    with serial.Serial(port, baudrate=baud, timeout=1) as device:
        LOG.info("Serial connection established.")
        LOG.info("Waiting for ESP32 telemetry...")

        while True:
            raw_line = device.readline()

            if not raw_line:
                continue

            line = raw_line.decode("utf-8", errors="replace").strip()

            if match := HANDSHAKE_RE.fullmatch(line):
                LOG.info(
                    "TLS handshake successful: %s ms",
                    match.group(1)
                )
                continue

            metric = parse_serial_line(line)

            if metric is None:
                continue

            try:
                post_metric(dashboard_url, metric)
            except (OSError, URLError, RuntimeError) as exc:
                LOG.error("Could not forward metric: %s", exc)
            else:
                LOG.info(
                    "Forwarded: %-22s %-9s %.2f ms",
                    metric["query"],
                    metric["status"],
                    metric["latency_ms"],
                )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)

    parser.add_argument(
        "--port",
        required=True,
        help="ESP32 serial port, e.g. COM4"
    )

    parser.add_argument("--baud", type=int, default=115200)

    parser.add_argument(
        "--dashboard-url",
        default="http://127.0.0.1:3001",
        help="Local dashboard URL"
    )

    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        stream=sys.stdout,
    )

    try:
        run(args.port, args.baud, args.dashboard_url)
    except KeyboardInterrupt:
        LOG.info("Serial bridge stopped.")
    except (OSError, URLError, RuntimeError) as exc:
        LOG.error("Serial bridge failed: %s", exc)
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
