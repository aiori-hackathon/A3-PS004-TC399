import express from 'express';
import http from 'node:http';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { Server } from 'socket.io';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 1e6 });
const PORT = Number(process.env.PORT || 3000);
const MAX_METRICS = 2000;
const MAX_DEVICE_EVENTS = 1200;
const metrics = [];
const deviceEvents = [];
const validStatuses = new Set([
  'SECURE', 'INSECURE', 'BOGUS', 'ERROR', 'BLOCKED_CD'
]);
const validDeviceKinds = new Set([
  'bridge_status', 'tls_handshake', 'tls_failure', 'dns_round_trip'
]);
const distDir = path.join(__dirname, 'dist');

app.disable('x-powered-by');
app.use(express.json({ limit: '16kb' }));
app.use(express.static(distDir, { index: false, maxAge: '1h' }));

function boundedNumber(value, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : 0;
}

app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'AegisDNS dashboard',
    metrics_count: metrics.length,
    device_events_count: deviceEvents.length,
    uptime_s: Math.floor(process.uptime()),
  });
});

// Gateway-originated DNS verdicts. This contract remains compatible with gateway.py.
app.get('/api/metrics', (_req, res) => {
  res.json({ metrics });
});

app.post('/api/metrics', (req, res) => {
  const input = req.body;
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    return res.status(400).json({ error: 'Expected a JSON object' });
  }
  if (typeof input.query !== 'string' || typeof input.status !== 'string' ||
      !validStatuses.has(input.status)) {
    return res.status(400).json({ error: 'Invalid metric fields' });
  }

  const metric = {
    id: randomUUID(),
    timestamp: typeof input.timestamp === 'string' ? input.timestamp : new Date().toISOString(),
    query: input.query.slice(0, 253),
    type: typeof input.type === 'string' ? input.type.slice(0, 20) : 'UNKNOWN',
    status: input.status,
    latency_ms: boundedNumber(input.latency_ms),
    cpu_percent: boundedNumber(input.cpu_percent, 0, 100),
    client: typeof input.client === 'string' ? input.client.slice(0, 64) : '',
    source: 'gateway',
  };

  metrics.push(metric);
  if (metrics.length > MAX_METRICS) metrics.shift();
  io.emit('dns_metric', metric);
  res.status(202).json({ accepted: true, id: metric.id });
});

// ESP32-side telemetry is kept separate from gateway DNS metrics. This avoids
// counting the same DNS request twice and preserves device round-trip timings.
app.get('/api/device/telemetry', (_req, res) => {
  res.json({ events: deviceEvents });
});

app.post('/api/device/telemetry', (req, res) => {
  const input = req.body;
  if (!input || typeof input !== 'object' || Array.isArray(input) ||
      typeof input.kind !== 'string' || !validDeviceKinds.has(input.kind)) {
    return res.status(400).json({ error: 'Invalid device telemetry event' });
  }

  const event = {
    id: randomUUID(),
    timestamp: typeof input.timestamp === 'string' ? input.timestamp : new Date().toISOString(),
    kind: input.kind,
    client: typeof input.client === 'string' ? input.client.slice(0, 64) : 'ESP32',
  };

  if (input.kind === 'bridge_status') {
    event.connected = input.connected === true;
    event.port = typeof input.port === 'string' ? input.port.slice(0, 16) : '';
  } else if (input.kind === 'tls_handshake') {
    event.handshake_ms = boundedNumber(input.handshake_ms, 0, 120000);
    event.free_heap = Math.round(boundedNumber(input.free_heap, 0, 10000000));
  } else if (input.kind === 'tls_failure') {
    event.code = Number.isInteger(Number(input.code)) ? Number(input.code) : null;
    event.message = typeof input.message === 'string' ? input.message.slice(0, 200) : '';
  } else if (input.kind === 'dns_round_trip') {
    event.query = typeof input.query === 'string' ? input.query.slice(0, 253) : 'unknown';
    event.rcode = Number.isInteger(Number(input.rcode)) ? Number(input.rcode) : null;
    event.response = typeof input.response === 'string' ? input.response.slice(0, 20) : '';
    event.ad = input.ad === true;
    event.id_match = input.id_match === true;
    event.status = validStatuses.has(input.status) ? input.status : 'ERROR';
    event.device_latency_ms = boundedNumber(input.device_latency_ms, 0, 120000);
    event.free_heap = Math.round(boundedNumber(input.free_heap, 0, 10000000));
  }

  deviceEvents.push(event);
  if (deviceEvents.length > MAX_DEVICE_EVENTS) deviceEvents.shift();
  io.emit('device_event', event);
  res.status(202).json({ accepted: true, id: event.id });
});

// Vite's React entry point. API and Socket.IO endpoints stay on the same origin.
app.get(/^\/(?!api\/|socket\.io\/).*/, (_req, res) => {
  res.sendFile(path.join(distDir, 'index.html'));
});

io.on('connection', (socket) => {
  console.log(`[Dashboard] Browser connected: ${socket.id}`);
  socket.on('disconnect', () => console.log(`[Dashboard] Browser disconnected: ${socket.id}`));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`AegisDNS NIGHTWATCH dashboard listening on port ${PORT}`);
});
