import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Activity, ArrowUpRight, Check, CircleHelp, Command, Download, Fingerprint,
  Gauge, Globe2, HardDrive, LockKeyhole, Network, Radio, Search, Shield,
  ShieldAlert, ShieldCheck, Unplug, X,
} from 'lucide-react';

const MAX_ITEMS = 2000;
const STATUS = {
  SECURE: { label: 'Verified', tone: 'secure', short: 'SECURE', detail: 'The resolver validated the DNSSEC chain and returned an authenticated answer.' },
  INSECURE: { label: 'Unsigned', tone: 'unsigned', short: 'INSECURE', detail: 'The name resolved, but no DNSSEC signature chain establishes its authenticity.' },
  BOGUS: { label: 'Rejected', tone: 'bogus', short: 'BOGUS', detail: 'DNSSEC validation failed. The resolver returned SERVFAIL instead of trusting the answer.' },
  BLOCKED_CD: { label: 'Blocked', tone: 'blocked', short: 'BLOCKED', detail: 'The gateway refused a request that attempted to disable checking.' },
  ERROR: { label: 'Error', tone: 'error', short: 'ERROR', detail: 'The request did not complete successfully.' },
};
const FILTERS = [
  ['ALL', 'All'], ['SECURE', 'Verified'], ['BOGUS', 'Rejected'],
  ['INSECURE', 'Unsigned'], ['BLOCKED_CD', 'Blocked'], ['ERROR', 'Errors'],
];

const timeOf = (v) => { const n = Date.parse(v || ''); return Number.isFinite(n) ? n : 0; };
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
const fmtMs = (v) => v === null || v === undefined || !Number.isFinite(Number(v)) ? '—' : `${Number(v) < 10 ? Number(v).toFixed(2) : Number(v) < 100 ? Number(v).toFixed(1) : Math.round(Number(v))} ms`;
const fmtTime = (v) => { const d = new Date(v); return Number.isNaN(d.getTime()) ? '—' : d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }); };
const fmtDate = (v) => { const d = new Date(v); return Number.isNaN(d.getTime()) ? '—' : d.toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }); };
const fmtAge = (v, now = Date.now()) => { const t = timeOf(v); if (!t) return 'No event yet'; const s = Math.max(0, Math.floor((now - t) / 1000)); return s < 2 ? 'Just now' : s < 60 ? `${s}s ago` : s < 3600 ? `${Math.floor(s / 60)}m ago` : `${Math.floor(s / 3600)}h ago`; };
const percentile = (values, p) => { if (!values.length) return null; const sorted = [...values].sort((a, b) => a - b); return sorted[Math.min(sorted.length - 1, Math.max(0, Math.ceil(p * sorted.length) - 1))]; };
const mean = (values) => values.length ? values.reduce((a, b) => a + b, 0) / values.length : null;
const meta = (s) => STATUS[s] || STATUS.ERROR;
function mergeNewest(item, list) {
  const id = item?.id || `${item?.timestamp}-${item?.query}-${item?.kind}`;
  return [item, ...list.filter((x) => (x.id || `${x.timestamp}-${x.query}-${x.kind}`) !== id)]
    .sort((a, b) => timeOf(b.timestamp) - timeOf(a.timestamp)).slice(0, MAX_ITEMS);
}
function uniqueNewest(list) {
  const seen = new Set();
  return [...list].sort((a, b) => timeOf(b.timestamp) - timeOf(a.timestamp)).filter((item) => {
    const key = item.id || `${item.timestamp}-${item.query}-${item.kind}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  }).slice(0, MAX_ITEMS);
}
function downloadCsv(rows) {
  const cols = ['timestamp', 'query', 'type', 'status', 'latency_ms', 'cpu_percent', 'client'];
  const cell = (v) => { let s = String(v ?? ''); if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; return `"${s.replaceAll('"', '""')}"`; };
  const csv = [cols.join(','), ...rows.slice().reverse().map((r) => cols.map((c) => cell(r[c])).join(','))].join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = document.createElement('a'); a.href = url; a.download = `aegisdns-events-${new Date().toISOString().slice(0, 10)}.csv`; a.click(); URL.revokeObjectURL(url);
}

function App() {
  const [metrics, setMetrics] = useState([]);
  const [devices, setDevices] = useState([]);
  const [socketState, setSocketState] = useState('connecting');
  const [apiState, setApiState] = useState('checking');
  const [apiError, setApiError] = useState('');
  const [filter, setFilter] = useState('ALL');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [now, setNow] = useState(Date.now());
  const bootstrapped = useRef(false);
  const early = useRef({ metrics: [], devices: [] });

  useEffect(() => {
    let alive = true;
    let socket;
    const interval = window.setInterval(() => setNow(Date.now()), 1000);
    const receiveMetric = (item) => {
      if (!alive) return;
      if (!bootstrapped.current) early.current.metrics.push(item);
      else setMetrics((prev) => mergeNewest(item, prev));
    };
    const receiveDevice = (item) => {
      if (!alive) return;
      if (!bootstrapped.current) early.current.devices.push(item);
      else setDevices((prev) => mergeNewest(item, prev));
    };
    if (typeof window.io === 'function') {
      socket = window.io({ reconnection: true, timeout: 5000 });
      socket.on('connect', () => setSocketState('online'));
      socket.on('disconnect', () => setSocketState('offline'));
      socket.on('connect_error', () => setSocketState('offline'));
      socket.on('dns_metric', receiveMetric);
      socket.on('device_event', receiveDevice);
    } else setSocketState('offline');

    const getJson = (url) => fetch(url).then((r) => { if (!r.ok) throw new Error(`${url}: HTTP ${r.status}`); return r.json(); });
    Promise.all([getJson('/api/metrics'), getJson('/api/device/telemetry')]).then(([m, d]) => {
      if (!alive) return;
      setMetrics(uniqueNewest([...(m.metrics || []), ...early.current.metrics]));
      setDevices(uniqueNewest([...(d.events || []), ...early.current.devices]));
      bootstrapped.current = true;
      setApiState('online'); setApiError('');
    }).catch((e) => {
      if (!alive) return;
      bootstrapped.current = true; setApiState('offline'); setApiError(e.message || 'Dashboard API unavailable');
    });

    const healthTimer = window.setInterval(() => {
      fetch('/health').then((r) => { if (!r.ok) throw new Error('Health check failed'); return r.json(); })
        .then(() => { if (alive) setApiState('online'); })
        .catch(() => { if (alive) setApiState('offline'); });
    }, 12000);
    return () => { alive = false; window.clearInterval(interval); window.clearInterval(healthTimer); if (socket) socket.disconnect(); };
  }, []);

  const counts = useMemo(() => {
    const c = { SECURE: 0, INSECURE: 0, BOGUS: 0, BLOCKED_CD: 0, ERROR: 0 };
    metrics.forEach((m) => { if (c[m.status] !== undefined) c[m.status] += 1; });
    return c;
  }, [metrics]);
  const latencies = useMemo(() => metrics.map((m) => num(m.latency_ms)), [metrics]);
  const p95 = percentile(latencies, .95);
  const median = percentile(latencies, .5);
  const average = mean(latencies);
  const latestMetric = metrics[0] || null;
  const bridge = devices.find((e) => e.kind === 'bridge_status') || null;
  const deviceSignals = devices.filter((e) => e.kind !== 'bridge_status');
  const latestSignal = deviceSignals[0] || null;
  const deviceFresh = Boolean(latestSignal && now - timeOf(latestSignal.timestamp) < 65000);
  const bridgeState = bridge?.connected && deviceFresh ? 'streaming' : bridge?.connected ? 'waiting' : bridge?.connected === false ? 'offline' : 'unknown';
  const handshakes = devices.filter((e) => e.kind === 'tls_handshake');
  const failures = devices.filter((e) => e.kind === 'tls_failure');
  const roundTrips = devices.filter((e) => e.kind === 'dns_round_trip');
  const lastHandshake = handshakes[0] || null;
  const lastRoundTrip = roundTrips[0] || null;
  const lastHeap = devices.find((e) => Number.isFinite(Number(e.free_heap))) || null;
  const filtered = useMemo(() => metrics.filter((m) => {
    if (filter !== 'ALL' && m.status !== filter) return false;
    const q = search.trim().toLowerCase();
    return !q || `${m.query} ${m.client} ${m.type} ${m.status}`.toLowerCase().includes(q);
  }), [metrics, filter, search]);
  const chartRows = useMemo(() => metrics.slice(0, 54).reverse(), [metrics]);
  const latestState = latestMetric ? meta(latestMetric.status) : null;
  const gatewayActive = Boolean(latestMetric && now - timeOf(latestMetric.timestamp) < 60000);

  return (
    <div className="observatory">
      <aside className="sidebar">
        <a className="wordmark" href="#overview" aria-label="AegisDNS overview">
          <span className="mark"><Shield size={19} strokeWidth={2.2} /></span>
          <span><b>Aegis<span>DNS</span></b><small>RESOLUTION SECURITY</small></span>
        </a>
        <div className="side-caption">WORKSPACE</div>
        <nav className="side-nav">
          <a className="active" href="#overview"><Activity size={17} /> Overview</a>
          <a href="#path"><Network size={17} /> Trust path</a>
          <a href="#performance"><Gauge size={17} /> Performance</a>
          <a href="#activity-log"><Command size={17} /> Event ledger</a>
        </nav>
        <div className="sidebar-bottom">
          <div className="environment-card">
            <span className="environment-label">RUNNING ENVIRONMENT</span>
            <div className="environment-value"><span className="env-dot" /> LOCAL LAB</div>
            <p>ESP32 edge client<br />DoT · mutual TLS · DNSSEC</p>
          </div>
          <div className="sidebar-foot"><span>AEGISDNS / 01</span><span>BUILD · NIGHTWATCH</span></div>
        </div>
      </aside>

      <main className="main" id="overview">
        <header className="topbar">
          <div className="crumb">SECURITY OBSERVABILITY <span>/</span> <b>OVERVIEW</b></div>
          <div className="topbar-right">
            <span className={`connection-state ${socketState}`}><i /> {socketState === 'online' ? 'Event stream connected' : socketState === 'connecting' ? 'Connecting to event stream' : 'Event stream disconnected'}</span>
            <span className="topbar-divider" />
            <span className={`api-state ${apiState}`}><i /> API {apiState === 'online' ? 'available' : apiState === 'checking' ? 'checking' : 'unavailable'}</span>
          </div>
        </header>

        <div className="page-content">
          {apiError && <div className="alert"><CircleHelp size={16} /> {apiError}</div>}
          <section className="intro">
            <div>
              <div className="overline"><span /> DNSSEC MONITORING / LOCAL NETWORK</div>
              <h1>Every answer<br /><em>has a trust story.</em></h1>
              <p className="intro-copy">A live view of the path from edge device to DNS answer — and the validation decision made along the way.</p>
            </div>
            <div className="intro-note">
              <div className="intro-note-top"><span>OBSERVATION WINDOW</span><span className="live-mark"><i /> LIVE</span></div>
              <strong>{metrics.length.toLocaleString()}</strong>
              <span>gateway decisions captured in this session</span>
              <div className="note-bottom"><span>LAST DECISION</span><b>{latestMetric ? fmtAge(latestMetric.timestamp, now) : 'Awaiting telemetry'}</b></div>
            </div>
          </section>

          <section className="summary-row" aria-label="DNSSEC outcome summary">
            <Summary label="Verified" value={counts.SECURE} detail="Valid DNSSEC chain" tone="secure" total={metrics.length} icon={ShieldCheck} />
            <Summary label="Rejected" value={counts.BOGUS} detail="Bogus signature / SERVFAIL" tone="bogus" total={metrics.length} icon={ShieldAlert} />
            <Summary label="Unsigned" value={counts.INSECURE} detail="Resolved without DNSSEC" tone="unsigned" total={metrics.length} icon={Globe2} />
            <Summary label="Blocked" value={counts.BLOCKED_CD} detail="Validation bypass refused" tone="blocked" total={metrics.length} icon={LockKeyhole} />
            <Summary label="Errors" value={counts.ERROR} detail="Other request failures" tone="error" total={metrics.length} icon={Unplug} />
          </section>

          <section className="trust-section" id="path">
            <div className="section-head">
              <div><span className="section-kicker">01 / REQUEST ARCHITECTURE</span><h2>The trust path</h2></div>
              <p>One request crosses four distinct roles.<br />Only the resolver makes the DNSSEC decision.</p>
            </div>
            <div className="path-panel">
              <div className="path-topline"><span>AEGISDNS / RESOLUTION PIPELINE</span><span className="path-legend"><i /> ARCHITECTURE VIEW · NOT A HEALTH CHECK</span></div>
              <div className="path-flow">
                <PathNode number="01" title="EDGE DEVICE" name="ESP32" description="DNS client" icon={Radio} foot="DoT · client certificate" />
                <PathLink protocol="TLS 1.3" />
                <PathNode number="02" title="SECURE GATEWAY" name="Aegis gateway" description="mTLS identity · request policy" icon={Shield} foot="Client authentication" />
                <PathLink protocol="DNS" />
                <PathNode number="03" title="VALIDATING RESOLVER" name="Unbound" description="DNSSEC chain validation" icon={Fingerprint} foot="AD flag · SERVFAIL" />
                <PathLink protocol="QUERY" />
                <PathNode number="04" title="AUTHORITATIVE ZONE" name="aegis.test" description="Signed test records" icon={Globe2} foot="Valid · bogus · unsigned" />
              </div>
              <div className="path-bottom"><span><b>SECURE</b> authenticated answer</span><span><b>BOGUS</b> rejected at validation</span><span><b>INSECURE</b> no DNSSEC assurance</span></div>
            </div>
          </section>

          <section className="insight-grid" id="performance">
            <div className="panel performance-panel">
              <div className="panel-heading">
                <div><span className="section-kicker">02 / GATEWAY METRICS</span><h2>Resolution latency</h2><p>Time measured by the gateway, from query receipt to response.</p></div>
                <span className="unit-label">MILLISECONDS</span>
              </div>
              <LatencyChart rows={chartRows} />
              <div className="chart-foot"><span><i className="legend-line" /> Gateway response time</span><span>{chartRows.length ? `Latest ${chartRows.length} observations` : 'No observations yet'}</span></div>
              <div className="stat-ribbon">
                <Stat label="MEDIAN" value={fmtMs(median)} />
                <Stat label="P95" value={fmtMs(p95)} />
                <Stat label="MEAN" value={fmtMs(average)} />
                <Stat label="LATEST CPU" value={latestMetric ? `${num(latestMetric.cpu_percent).toFixed(1)}%` : '—'} />
              </div>
            </div>

            <aside className={`panel latest-panel ${latestState ? `latest-${latestState.tone}` : ''}`}>
              <div className="panel-heading latest-heading"><div><span className="section-kicker">03 / MOST RECENT DECISION</span><h2>Latest verdict</h2></div><span className="decision-index">LIVE</span></div>
              {latestMetric ? <>
                <div className="verdict-main"><span className={`verdict-symbol ${latestState.tone}`}>{latestState.tone === 'secure' ? <Check /> : latestState.tone === 'unsigned' ? <Globe2 /> : latestState.tone === 'bogus' ? <ShieldAlert /> : <Activity />}</span><span className={`verdict-word ${latestState.tone}`}>{latestState.label}</span></div>
                <div className="latest-domain">{(latestMetric.query || 'unknown').replace(/\.$/, '')}</div>
                <p className="latest-description">{latestState.detail}</p>
                <div className="latest-details">
                  <Detail label="GATEWAY LATENCY" value={fmtMs(latestMetric.latency_ms)} />
                  <Detail label="DNS TYPE" value={latestMetric.type || '—'} />
                  <Detail label="CLIENT" value={latestMetric.client || '—'} />
                  <Detail label="RECEIVED" value={fmtDate(latestMetric.timestamp)} />
                </div>
              </> : <EmptyState title="No DNS decisions yet" detail="The latest gateway verdict will appear here when the first metric is received." />}
            </aside>
          </section>

          <section className="device-section">
            <div className="section-head device-head">
              <div><span className="section-kicker">04 / EDGE TELEMETRY</span><h2>Device diagnostics</h2></div>
              <span className={`device-status state-${bridgeState}`}><i />{bridgeState === 'streaming' ? 'Receiving device telemetry' : bridgeState === 'waiting' ? 'Serial port open · waiting for records' : bridgeState === 'offline' ? 'Bridge disconnected' : 'No bridge status received'}</span>
            </div>
            <div className="device-grid">
              <DeviceMetric icon={Radio} label="SERIAL BRIDGE" value={bridge?.connected ? 'Port open' : bridge?.connected === false ? 'Disconnected' : 'Unknown'} detail={bridge?.port ? `Windows ${bridge.port}` : 'No port reported'} />
              <DeviceMetric icon={LockKeyhole} label="LAST TLS HANDSHAKE" value={lastHandshake ? fmtMs(lastHandshake.handshake_ms) : '—'} detail={lastHandshake ? fmtAge(lastHandshake.timestamp, now) : 'No handshake event'} />
              <DeviceMetric icon={Activity} label="ESP32 ROUND TRIP" value={lastRoundTrip ? fmtMs(lastRoundTrip.device_latency_ms) : '—'} detail={roundTrips.length ? `${roundTrips.length} device DNS records` : 'No DNS record received'} />
              <DeviceMetric icon={HardDrive} label="FREE HEAP" value={lastHeap ? `${(num(lastHeap.free_heap) / 1024).toFixed(1)} KB` : '—'} detail={lastHeap ? `${num(lastHeap.free_heap).toLocaleString()} bytes` : 'No memory sample'} />
            </div>
            <div className="device-footnote"><span><b>{handshakes.length}</b> successful handshakes</span><span><b>{failures.length}</b> TLS connection failures</span><span><b>{roundTrips.length}</b> device-side DNS results</span><span className="footnote-explain">Device timings include Wi-Fi and TLS overhead; gateway timings do not.</span></div>
          </section>

          <section className="ledger-section" id="activity-log">
            <div className="section-head ledger-head">
              <div><span className="section-kicker">05 / AUDIT TRAIL</span><h2>DNS event ledger</h2></div>
              <button className="export-button" onClick={() => downloadCsv(filtered)} disabled={!filtered.length}><Download size={15} /> Export CSV</button>
            </div>
            <div className="ledger-controls">
              <div className="filter-list" role="group" aria-label="Filter DNS decisions">
                {FILTERS.map(([key, label]) => <button key={key} type="button" className={filter === key ? 'filter-active' : ''} onClick={() => setFilter(key)}>{label}<span>{key === 'ALL' ? metrics.length : counts[key]}</span></button>)}
              </div>
              <label className="search-field"><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search domain, client or verdict" /><kbd>⌕</kbd></label>
            </div>
            <div className="table-wrap">
              <table>
                <thead><tr><th>TIME</th><th>DOMAIN</th><th>TYPE</th><th>VERDICT</th><th>LATENCY</th><th>CLIENT</th><th></th></tr></thead>
                <tbody>
                  {filtered.slice(0, 100).map((row) => <tr key={row.id} className={selected?.id === row.id ? 'selected-row' : ''} onClick={() => setSelected(row)} tabIndex="0" onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') setSelected(row); }}>
                    <td className="time-cell">{fmtTime(row.timestamp)}</td><td className="domain-cell">{(row.query || 'unknown').replace(/\.$/, '')}</td><td>{row.type || '—'}</td><td><StatusTag status={row.status} /></td><td className="latency-cell">{fmtMs(row.latency_ms)}</td><td className="client-cell">{row.client || '—'}</td><td className="row-arrow">↗</td>
                  </tr>)}
                  {!filtered.length && <tr><td colSpan="7" className="empty-table">{metrics.length ? 'No records match this filter.' : 'Waiting for gateway DNS metrics. The event ledger will populate automatically.'}</td></tr>}
                </tbody>
              </table>
            </div>
            <div className="ledger-footer"><span>SHOWING {Math.min(filtered.length, 100)} OF {filtered.length} MATCHING RECORDS</span><span>GATEWAY METRICS ONLY · DEVICE SERIAL EVENTS ARE LISTED ABOVE</span></div>
            {selected && <div className="record-inspector"><div><span className="section-kicker">SELECTED RECORD</span><strong>{selected.query}</strong><p>{meta(selected.status).detail}</p></div><div><span>DECISION</span><b>{meta(selected.status).short}</b></div><div><span>TIMESTAMP</span><b>{fmtDate(selected.timestamp)}</b></div><button onClick={() => setSelected(null)} aria-label="Close selected record"><X size={16} /></button></div>}
          </section>

          <footer className="footer"><span>AEGISDNS <i /> DNSSEC OBSERVABILITY</span><span>SESSION DATA IS HELD IN MEMORY · RESTARTING THE DASHBOARD CLEARS THE CURRENT COUNTS</span></footer>
        </div>
      </main>
    </div>
  );
}

function Summary({ label, value, detail, tone, total, icon: Icon }) {
  const pct = total ? Math.min(100, (value / total) * 100) : 0;
  return <article className={`summary-item ${tone}`}><div className="summary-top"><span>{label}</span><Icon size={17} strokeWidth={1.8} /></div><strong>{value.toLocaleString()}</strong><p>{detail}</p><div className="summary-bottom"><span>{total ? `${pct.toFixed(0)}% of decisions` : 'No decisions yet'}</span><div className="summary-track"><i style={{ width: `${pct}%` }} /></div></div></article>;
}
function PathNode({ number, title, name, description, icon: Icon, foot }) {
  return <div className="path-node"><div className="node-meta"><span>{number}</span><span>{title}</span></div><div className="node-icon"><Icon size={21} strokeWidth={1.7} /></div><strong>{name}</strong><p>{description}</p><small>{foot}</small></div>;
}
function PathLink({ protocol }) { return <div className="path-link"><span>{protocol}</span><div><i /></div><ArrowUpRight size={14} /></div>; }
function Stat({ label, value }) { return <div className="stat"><span>{label}</span><b>{value}</b></div>; }
function Detail({ label, value }) { return <div className="detail"><span>{label}</span><b>{value}</b></div>; }
function DeviceMetric({ icon: Icon, label, value, detail }) { return <article className="device-metric"><div className="device-metric-icon"><Icon size={17} /></div><span className="device-label">{label}</span><strong>{value}</strong><small>{detail}</small></article>; }
function StatusTag({ status }) { const m = meta(status); return <span className={`status-tag ${m.tone}`}><i />{m.short}</span>; }
function EmptyState({ title, detail }) { return <div className="empty-state"><span><Activity size={21} /></span><strong>{title}</strong><p>{detail}</p></div>; }

function LatencyChart({ rows }) {
  if (!rows.length) return <div className="chart-empty"><div className="chart-empty-mark"><Activity size={22} /></div><strong>No latency samples yet</strong><span>The chart is drawn from gateway-reported response times as DNS decisions arrive.</span></div>;
  const width = 760, height = 218, left = 42, right = 12, top = 14, bottom = 28;
  const values = rows.map((r) => num(r.latency_ms));
  const max = Math.max(10, Math.ceil(Math.max(...values) / 10) * 10);
  const plotW = width - left - right, plotH = height - top - bottom;
  const pts = values.map((v, i) => ({ x: rows.length === 1 ? width / 2 : left + (i / (rows.length - 1)) * plotW, y: top + (1 - Math.min(v, max) / max) * plotH, v, row: rows[i] }));
  const line = pts.map((p, i) => `${i ? 'L' : 'M'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  const area = `${line} L ${pts[pts.length - 1].x} ${height - bottom} L ${pts[0].x} ${height - bottom} Z`;
  return <div className="chart-wrap"><svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Gateway DNS response time history in milliseconds">
    {[0, 1, 2, 3].map((i) => { const y = top + (i / 3) * plotH; return <g key={i}><line x1={left} x2={width - right} y1={y} y2={y} className="grid-line" /><text x="1" y={y + 4} className="axis-text">{Math.round(max * (1 - i / 3))}</text></g>; })}
    <path d={area} className="chart-area" /><path d={line} className="chart-path" />
    {pts.map((p, i) => <circle key={p.row.id || i} cx={p.x} cy={p.y} r="3.6" className={`chart-dot dot-${meta(p.row.status).tone}`}><title>{`${p.row.query}: ${fmtMs(p.v)} · ${meta(p.row.status).label}`}</title></circle>)}
    <text x={left} y={height - 5} className="axis-text">{fmtTime(rows[0].timestamp)}</text><text x={width - right} y={height - 5} textAnchor="end" className="axis-text">{fmtTime(rows[rows.length - 1].timestamp)}</text>
  </svg></div>;
}

export default App;
