"""Forward structured ESP32 serial telemetry to the AegisDNS NIGHTWATCH API."""

import argparse
import importlib
import json
import logging
import re
import sys
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

LOG = logging.getLogger("esp32-nightwatch-bridge")

HANDSHAKE_RE = re.compile(
    r"^TLS_HANDSHAKE_OK,handshake_ms=(\d+),free_heap=(\d+)$"
)
TLS_FAILURE_RE = re.compile(r"^TLS_CONNECT_FAILED,code=(-?\d+),(.*)$")
RESULT_RE = re.compile(
    r"^RESULT,([^,]+),([^,]+),rcode=(\d+),AD=([01]),"
    r"id_match=([01]),latency_ms=(\d+(?:\.\d+)?),free_heap=(\d+)$"
)


def parse_serial_line(line: str) -> dict | None:
    """Map firmware log records to the separate device-telemetry contract."""
    line = line.strip()

    if match := HANDSHAKE_RE.fullmatch(line):
        return {
            "kind": "tls_handshake",
            "handshake_ms": int(match.group(1)),
            "free_heap": int(match.group(2)),
            "client": "ESP32",
        }

    if match := TLS_FAILURE_RE.fullmatch(line):
        return {
            "kind": "tls_failure",
            "code": int(match.group(1)),
            "message": match.group(2)[:200],
            "client": "ESP32",
        }

    if match := RESULT_RE.fullmatch(line):
        query = match.group(1)[:253]
        response = match.group(2).upper()[:20]
        rcode = int(match.group(3))
        ad = match.group(4) == "1"
        id_match = match.group(5) == "1"
        latency = float(match.group(6))
        free_heap = int(match.group(7))

        if rcode == 0 and ad:
            status = "SECURE"
        elif rcode == 0 and not ad:
            status = "INSECURE"
        elif rcode == 2 and query.rstrip(".").lower() == "bogus.aegis.test":
            status = "BOGUS"
        else:
            status = "ERROR"

        return {
            "kind": "dns_round_trip",
            "query": query,
            "response": response,
            "rcode": rcode,
            "ad": ad,
            "id_match": id_match,
            "status": status,
            "device_latency_ms": latency,
            "free_heap": free_heap,
            "client": "ESP32",
        }

    return None


def post_event(dashboard_url: str, event: dict) -> None:
    payload = dict(event)
    payload["timestamp"] = datetime.now(timezone.utc).isoformat()
    request = Request(
        f"{dashboard_url.rstrip('/')}/api/device/telemetry",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=3) as response:
        if response.status != 202:
            raise RuntimeError(f"Dashboard returned HTTP {response.status}")


def try_post(dashboard_url: str, event: dict) -> bool:
    try:
        post_event(dashboard_url, event)
        return True
    except (OSError, HTTPError, URLError, RuntimeError) as exc:
        LOG.error("Could not forward %s telemetry: %s", event.get("kind"), exc)
        return False


def run(port: str, baud: int, dashboard_url: str) -> None:
    try:
        serial = importlib.import_module("serial")
    except ImportError as exc:
        raise RuntimeError(
            "pyserial is required. Install it with your PlatformIO Python: "
            "<pio-python> -m pip install pyserial"
        ) from exc

    LOG.info("Opening ESP32 serial port %s at %d baud", port, baud)
    LOG.info("Device telemetry endpoint: %s/api/device/telemetry", dashboard_url)

    with serial.Serial(port, baudrate=baud, timeout=1) as device:
        try_post(dashboard_url, {
            "kind": "bridge_status", "connected": True, "port": port, "client": "ESP32"
        })
        LOG.info("Serial connection established. Waiting for ESP32 telemetry...")
        try:
            while True:
                raw_line = device.readline()
                if not raw_line:
                    continue
                line = raw_line.decode("utf-8", errors="replace").strip()
                event = parse_serial_line(line)
                if event is None:
                    continue
                if try_post(dashboard_url, event):
                    kind = event["kind"]
                    if kind == "tls_handshake":
                        LOG.info(
                            "TLS handshake %.0f ms · free heap %s bytes",
                            event["handshake_ms"], event["free_heap"]
                        )
                    elif kind == "tls_failure":
                        LOG.warning("TLS connection failed: code=%s %s", event["code"], event["message"])
                    else:
                        LOG.info(
                            "Device DNS %-22s %-9s %.2f ms · ID %s",
                            event["query"], event["status"], event["device_latency_ms"],
                            "MATCH" if event["id_match"] else "MISMATCH"
                        )
        finally:
            try_post(dashboard_url, {
                "kind": "bridge_status", "connected": False, "port": port, "client": "ESP32"
            })


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", required=True, help="ESP32 serial port, e.g. COM4")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument(
        "--dashboard-url",
        default="http://127.0.0.1:3001",
        help="Local dashboard base URL",
    )
    args = parser.parse_args()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        stream=sys.stdout,
    )
    try:
        run(args.port, args.baud, args.dashboard_url)
    except KeyboardInterrupt:
        LOG.info("Serial bridge stopped.")
    except (OSError, URLError, RuntimeError) as exc:
        LOG.error("Serial bridge failed: %s", exc)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
